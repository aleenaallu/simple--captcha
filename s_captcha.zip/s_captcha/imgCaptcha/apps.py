from django.apps import AppConfig


class ImgcaptchaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'imgCaptcha'
