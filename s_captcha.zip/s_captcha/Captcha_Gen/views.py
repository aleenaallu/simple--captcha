from django.shortcuts import render

# Create your views here.
from .my_Captcha import FormWithCaptcha

def home(request):
    context={
        'captcha':FormWithCaptcha
    }
    return render(request,'home.html',context)
    