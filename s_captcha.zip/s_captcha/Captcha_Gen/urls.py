from django.urls import path
from django.contrib import admin
from Captcha_Gen import views

urlpatterns=[
    path('',views.home,name='home')
]